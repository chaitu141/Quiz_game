package com.example.chaitanya_quiz;

public class Helper {
    private Question[] questions = new Question[5];


    public Helper() {
        questions[0] = new Question("What is the Capital city of US ?",
                new String[]{"Chicago", "New York", "Washington DC"},
                new int[]{2}
        );
        questions[1] = new Question("What is the Capital of India",
                new String[]{"Mumbai", "Delhi", "Hyderabad"},
                new int[]{1}
        );
        questions[2] = new Question("What are the capitals of Malaysia?(multiple answers)",
                new String[]{"kuala Lumpur", "Putrajaya","George Town"},

                new int[]{0, 1}
        );
        questions[3] = new Question("What is the capital of UK?",
                new String[]{"London","Bristol","Edinburgh"},
                new int[]{0}
        );
        questions[4] = new Question("Who is the president of US?",
                new String[]{"Barack Obama","Donald Trump","Joe Biden"},
                new int[]{2}
        );

    }

    public Question[] getQuestions() {
        return questions;
    }
}

